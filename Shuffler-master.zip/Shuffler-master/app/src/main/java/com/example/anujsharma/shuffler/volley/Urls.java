package com.example.anujsharma.shuffler.volley;

/**
 * Created by anuj5 on 02-01-2018.
 */

public class Urls {

    public static final String CLIENT_ID = "L769F50feEmlOI4zzWlSaA4DWuQfPmc8";
    public static final String TRACKS = "http://api.soundcloud.com/tracks";
    public static final String USERS = "http://api.soundcloud.com/users";
    public static final String PLAYLISTS = "http://api.soundcloud.com/playlists";

}
