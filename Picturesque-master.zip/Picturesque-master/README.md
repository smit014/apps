<h1 align="center">
  <br>
  <a href="https://habibrehman.com/work/picturesque"><img src="https://user-images.githubusercontent.com/4217124/110836994-a46a4580-8298-11eb-8d28-c8cc30a82e8d.png" alt="Picturesque" width="150" style= "margin-bottom: 1rem"></a>
  <br>
  Picturesque
  <br>
  <br>
</h1>


<h4 align="center">An elegant, minimal and feature-rich wallpaper app.</h4>
<br>

![preview](https://user-images.githubusercontent.com/4217124/110837118-c237aa80-8298-11eb-9b16-4d865f06b1be.png)

### More info at https://habibrehman.com/work/picturesque


### License

Copyright (C) 2018 Habib Rehman (https://git.io/HR)

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
